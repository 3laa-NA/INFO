#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/times.h>
#include <time.h>


void lance_commande(char *commande){
    struct timeval tv;
    struct timeval tv2;

    gettimeofday(&tv, NULL);

    if(system(commande)){
        printf("la commande '%s' n’a pu être exécutée correctement.\n", commande);
        return;
    }
    
    gettimeofday(&tv2, NULL);

    double t2 = (tv2.tv_sec)*pow(10,6) + (tv2.tv_usec);
    double t1 = (tv.tv_sec)*pow(10,6) + (tv.tv_usec);

    printf("le temps mis par l'exécution de la commande '%s' : %f s\n", commande, (t2-t1)/1e6);

}

void new_lance_commande(char *commande){
    struct tms t1, t2;
    clock_t debut, fin;
    long ticks_per_sec = sysconf(_SC_CLK_TCK); // Nombre de ticks par seconde


    debut = times(&t1);

    if(system(commande)){
        printf("la commande '%s' n’a pu être exécutée correctement.\n", commande);
        return;
    }
    
    fin = times(&t2);

    unsigned long ms = (fin -  debut) * 1000 / CLOCKS_PER_SEC;

    double elapsed_time = (double)(fin - debut) / ticks_per_sec;
    double user_time = (double)(t2.tms_utime - t1.tms_utime) / ticks_per_sec;
    double system_time = (double)(t2.tms_stime - t1.tms_stime) / ticks_per_sec;
    double user_child_time = (double)(t2.tms_cutime - t1.tms_cutime) / ticks_per_sec;
    double system_child_time = (double)(t2.tms_cstime - t1.tms_cstime) / ticks_per_sec;

    printf("Statistiques de '%s' :\n", commande);
    printf("Temps total : %.6f\n", elapsed_time);
    printf("Temps utilisateur : %.6f\n", user_time);
    printf("Temps système : %.6f\n", system_time);
    printf("Temps utilisateur fils : %.6f\n", user_child_time);
    printf("Temps système fils : %.6f\n\n", system_child_time);
}


int main(int argc, char *argv[]) {

    if(argc == 1){
        printf("Il manque les arguments!\n");
        return 1;
    }

    for (int i=1; i<argc; i++){
        //lance_commande(argv[i]);
        new_lance_commande(argv[i]);
    }
    
    return 0;
}
