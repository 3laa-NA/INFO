#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <sys/resource.h>


int main(void) {

    for (int i = 0; i < 5*pow(10,9); i++){}

    return 0;
}


