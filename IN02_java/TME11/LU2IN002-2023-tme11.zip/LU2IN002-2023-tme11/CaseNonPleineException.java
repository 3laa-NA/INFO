/*
 Alaa ALABOUD
 Ichraq MOHAMMAD
*/

public class CaseNonPleineException extends Exception {
    public CaseNonPleineException (String message){
        super(message);
    }
}
