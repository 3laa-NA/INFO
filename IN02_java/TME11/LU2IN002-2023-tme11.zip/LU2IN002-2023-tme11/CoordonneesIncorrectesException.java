/*
 Alaa ALABOUD
 Ichraq MOHAMMAD
*/

public class CoordonneesIncorrectesException extends Exception {
    public CoordonneesIncorrectesException (String message){
        super(message);
    }
}

