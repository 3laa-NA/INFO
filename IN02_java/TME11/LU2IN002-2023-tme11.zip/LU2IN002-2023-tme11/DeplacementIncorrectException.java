/*
 Alaa ALABOUD
 Ichraq MOHAMMAD
*/

public class DeplacementIncorrectException extends Exception {
    public DeplacementIncorrectException(){
        super("Deplacement Incorrect Exception");
    }
}
